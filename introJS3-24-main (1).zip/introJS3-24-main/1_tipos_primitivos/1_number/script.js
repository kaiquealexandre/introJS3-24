//tipo number

const meuNumero = 12;

const telefone = 44998268318;

const idade = 16;

console.log(meuNumero);
console.log(telefone);
console.log(idade);


const soma = meuNumero + idade

console.log(soma)