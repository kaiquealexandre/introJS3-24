const text1 = "Olá mundo";
const text2 = 'Olá mundo';
const senha = "senhasupersegura";
const StringDeNumeros = "3642";

// concatenação (+)

const citacao = "Meu nome é";
const meuNome = " Leo" ;

console.log(citacao + meuNome);

//comparaçao

console.log(text1 === text2);

const n1 = 1;

const n2 = 2;

console.log(n1 === n2)