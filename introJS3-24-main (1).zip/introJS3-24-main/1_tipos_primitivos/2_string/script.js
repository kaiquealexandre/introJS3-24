const texto1 = "kaique cupin";
const texto2 = 'gabziin';
const texto3 = ' foi no "Banheiro"';

console.log(texto1);
console.log(texto2);

console.log(texto2 + texto3);

const cifrao = '\u0024';
const aMaiusculo = '\u0041';

console.log(cifrao);
console.log(aMaiusculo);